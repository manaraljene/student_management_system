<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="com.enit.entities.Speciality" %>
<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
            color: #333;
        }
        header {
            background-color: #007BFF;
            color: white;
            padding: 15px;
            text-align: center;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .form-section {
            margin-bottom: 30px;
        }
        input[type="text"], button {
            display: block;
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 15px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .action-button {
            background-color: #f44336;
            color: white;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .action-button:hover {
            background-color: #da190b;
        }
        footer {
            text-align: center;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>Manage Specialities</h1>
    </header>
    <div class="container">
        <h2>${speciality != null ? 'Edit Speciality' : 'Add New Speciality'}</h2>
        <div class="form-section">
            <form action="specialities" method="post">
                <input type="hidden" name="action" value="${speciality != null ? 'update' : 'add'}">
                <input type="text" name="name" placeholder="Speciality Name" value="${speciality.nameSpeciality}" required>
                <button type="submit">${speciality != null ? 'Update' : 'Add'} Speciality</button>
            </form>
        </div>
        
        <h2>Speciality List</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <%
                    List<Speciality> specialities = (List<Speciality>) request.getAttribute("specialities");
                    if (specialities != null && !specialities.isEmpty()) {
                        for (Speciality speciality : specialities) {
                %>
                            <tr>
                                <td><%= speciality.getIdSpeciality() %></td>
                                <td><%= speciality.getNameSpeciality() %></td>
                                <td>
                                    <form action="specialities" method="get" style="display:inline;">
                                        <input type="hidden" name="action" value="edit">
                                        <input type="hidden" name="id" value="<%= speciality.getIdSpeciality() %>">
                                        <button type="submit">Edit</button>
                                    </form>
                                    <form action="specialities" method="post" style="display:inline;">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<%= speciality.getIdSpeciality() %>">
                                        <button type="submit" class="action-button" onclick="return confirm('Are you sure you want to delete this speciality?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                <%
                        }
                    } else {
                %>
                        <tr>
                            <td colspan="3">No specialities found.</td>
                        </tr>
                <%
                    }
                %>
            </tbody>
        </table>
    </div>
    <footer>
        &copy; 2025 Speciality Management System
    </footer>
</body>
</html>
