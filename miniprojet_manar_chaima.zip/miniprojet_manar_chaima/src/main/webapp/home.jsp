<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            color: #333;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #007BFF;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        nav {
            display: flex;
            justify-content: center;
            background-color: #0056b3;
            padding: 10px 0;
        }
        nav a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            font-weight: bold;
        }
        nav a:hover {
            background-color: #004494;
            border-radius: 5px;
        }
        .container {
            margin: 20px auto;
            max-width: 1200px;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center; /* Centering the content */
        }
        h1, h2 {
            margin-top: 0;
        }
        .buttons {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }
        .buttons form {
            margin: 10px;
        }
        .buttons button {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 15px 25px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .buttons button:hover {
            background-color: #0056b3;
        }
        footer {
            text-align: center;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to the Student Management System</h1>
    </header>
    <nav>
        <a href="student.jsp">Manage Student</a>
        <a href="exam.jsp">Manage Exam</a>
        <a href="speciality.jsp">Manage Speciality</a>
        <a href="session.jsp">Manage Session</a>
    </nav>
    <div class="container">
        <h2>Dashboard</h2>
        <div class="buttons">
            <form action="student.jsp">
                <button type="submit">Manage Student</button>
            </form>
            <form action="exam.jsp">
                <button type="submit">Manage Exam</button>
            </form>
            <form action="speciality.jsp">
                <button type="submit">Manage Speciality</button>
            </form>
            <form action="session.jsp">
                <button type="submit">Manage Session</button>
            </form>
        </div>
    </div>
    <footer>
        &copy; 2025 Student Management System
    </footer>
</body>
</html>
