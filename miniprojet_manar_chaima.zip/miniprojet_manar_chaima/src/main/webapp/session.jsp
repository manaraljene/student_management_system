<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="com.enit.entities.Session" %>
<%@ page import="com.enit.entities.SessionId" %>
<%@ page import="java.util.ArrayList" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Sessions</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            color: #333;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #007BFF;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        .container {
            margin: 20px auto;
            max-width: 1200px;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            margin-top: 0;
            text-align: center;
        }
        .form-section {
            display: flex;
            justify-content: space-around;
            margin-bottom: 20px;
        }
        .form-section form {
            background-color: #eef1f5;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .form-section input[type="text"], .form-section input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .form-section button {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .form-section button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        footer {
            text-align: center;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
        .action-button {
            background-color: #FF4B4B;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 3px;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }
        .action-button:hover {
            background-color: #FF0000;
        }
    </style>
</head>
<body>
    <header>
        <h1>Manage Sessions</h1>
    </header>
    <div class="container">
        <h2>Add a New Session</h2>
        <div class="form-section">
            <form action="sessions" method="post">
                <input type="hidden" name="action" value="add">
                <input type="text" name="idStudent" placeholder="Student ID" required>
                <input type="number" name="idExam" placeholder="Exam ID" required>
                <input type="number" step="0.01" name="mark" placeholder="Mark" required>
                <button type="submit">Add Session</button>
            </form>
        </div>
        <h2>Session List</h2>
        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Exam ID</th>
                    <th>Mark</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <%
                    @SuppressWarnings("unchecked")
                    List<Session> sessionList = (List<Session>) request.getAttribute("sessions");
                    if (sessionList != null) {
                        for (Session sessionItem : sessionList) {
                %>
                            <tr>
                                <td><%= sessionItem.getSessionId().getIdStudent() %></td>
                                <td><%= sessionItem.getSessionId().getIdExam() %></td>
                                <td><%= sessionItem.getMark() %></td>
                                <td>
                                    <form action="sessions" method="post" style="display:inline;">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="idStudent" value="<%= sessionItem.getSessionId().getIdStudent() %>">
                                        <input type="hidden" name="idExam" value="<%= sessionItem.getSessionId().getIdExam() %>">
                                        <button type="submit" class="action-button">Delete</button>
                                    </form>
                                </td>
                            </tr>
                <%
                        }
                    } else {
                %>
                        <tr>
                            <td colspan="4">No sessions found.</td>
                        </tr>
                <%
                    }
                %>
            </tbody>
        </table>
    </div>
    <footer>
        &copy; 2025 Session Management System
    </footer>
</body>
</html>
