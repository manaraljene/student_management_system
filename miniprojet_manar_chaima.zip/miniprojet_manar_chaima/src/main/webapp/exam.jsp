<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="com.enit.entities.Exam" %>
<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
            color: #333;
        }
        header {
            background-color: #007BFF;
            color: white;
            padding: 15px;
            text-align: center;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .form-section {
            margin-bottom: 30px;
        }
        input[type="text"], button {
            display: block;
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 15px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .action-button {
            background-color: #f44336;
            color: white;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .action-button:hover {
            background-color: #da190b;
        }
        footer {
            text-align: center;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>Manage Exams</h1>
    </header>
    <div class="container">
        <h2>${exam != null ? 'Edit Exam' : 'Add New Exam'}</h2>
        <div class="form-section">
            <form action="exams" method="post">
                <input type="hidden" name="action" value="${exam != null ? 'update' : 'add'}">
                <input type="text" name="title" placeholder="Exam Title" value="${exam.titleExam}" required>
                <button type="submit">${exam != null ? 'Update' : 'Add'} Exam</button>
            </form>
        </div>
        
        <h2>Exam List</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <%
                    List<Exam> exams = (List<Exam>) request.getAttribute("exams");
                    if (exams != null && !exams.isEmpty()) {
                        for (Exam exam : exams) {
                %>
                            <tr>
                                <td><%= exam.getIdExam() %></td>
                                <td><%= exam.getTitleExam() %></td>
                                <td>
                                    <form action="exams" method="get" style="display:inline;">
                                        <input type="hidden" name="action" value="edit">
                                        <input type="hidden" name="id" value="<%= exam.getIdExam() %>">
                                        <button type="submit">Edit</button>
                                    </form>
                                    <form action="exams" method="post" style="display:inline;">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<%= exam.getIdExam() %>">
                                        <button type="submit" class="action-button" onclick="return confirm('Are you sure you want to delete this exam?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                <%
                        }
                    } else {
                %>
                        <tr>
                            <td colspan="3">No exams found.</td>
                        </tr>
                <%
                    }
                %>
            </tbody>
        </table>
    </div>
    <footer>
        &copy; 2025 Exam Management System
    </footer>
</body>
</html>
