package com.enit.service;

import java.util.List;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import com.enit.entities.Student;



@Stateless
public class StudentLocalImp implements StudentLocal {
    @PersistenceContext(unitName = "ENIT")
    private EntityManager em;

    @Override
    public boolean addStudent(Student student) {
        try {
            em.persist(student);
            em.flush();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Student> getAllStudents() {
        try {
            return em.createQuery("SELECT s FROM Student s", Student.class).getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Student getStudentById(String studentId) {
        try {
            return em.find(Student.class, studentId);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean updateStudent(Student student) {
        try {
            em.merge(student);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteStudent(String studentId) {
        try {
            Student student = em.find(Student.class, studentId);
            if (student != null) {
                em.remove(student);
                return true;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}