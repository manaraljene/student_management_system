package com.enit.service;

import java.util.List;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import com.enit.entities.Session;

@Stateless
public class SessionLocalImp implements SessionLocal {

    @PersistenceContext(unitName = "ENIT")
    private EntityManager em;

    @Override
    public void add(Session session) {
        em.persist(session);
    }

    @Override
    public void update(Session session) {
        em.merge(session);
    }


    @Override
    public List<Session> findAll() {
        return em.createQuery("SELECT s FROM Session s", Session.class).getResultList();
    }
}
