package com.enit.service;

import java.util.List;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import com.enit.entities.Exam;

@Stateless
public class ExamLocalImp implements ExamLocal {

    @PersistenceContext(unitName = "ENIT")
    private EntityManager em;

    @Override
    public void add(Exam exam) {
        em.persist(exam);
    }

    @Override
    public void update(Exam exam) {
        em.merge(exam);
    }

    @Override
    public void delete(int id) {
        Exam exam = em.find(Exam.class, id);
        if (exam != null) {
            em.remove(exam);
        }
    }

    @Override
    public List<Exam> findAll() {
        return em.createQuery("SELECT e FROM Exam e", Exam.class).getResultList();
    }
}
