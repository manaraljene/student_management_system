package com.enit.service;

import java.util.List;
import jakarta.ejb.Local;

import com.enit.entities.Session;
import com.enit.entities.SessionId;

@Local
public interface SessionLocal {
    void add(Session session);

    void update(Session session);

    List<Session> findAll();
}
