package com.enit.service;

import java.util.List;
import jakarta.ejb.Local;
import com.enit.entities.Student;

@Local
public interface StudentLocal {
    boolean addStudent(Student student);
    List<Student> getAllStudents();
    Student getStudentById(String studentId);
    boolean updateStudent(Student student);
    boolean deleteStudent(String studentId);
}