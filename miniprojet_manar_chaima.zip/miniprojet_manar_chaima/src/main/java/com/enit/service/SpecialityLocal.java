package com.enit.service;

import java.util.List;
import jakarta.ejb.Local;

import com.enit.entities.Speciality;

@Local
public interface SpecialityLocal {
    void add(Speciality speciality);

    void update(Speciality speciality);

    void delete(int id);

    List<Speciality> findAll();
}
