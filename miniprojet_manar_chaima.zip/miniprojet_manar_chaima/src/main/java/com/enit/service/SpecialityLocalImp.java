package com.enit.service;

import java.util.List;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import com.enit.entities.Speciality;

@Stateless
public class SpecialityLocalImp implements SpecialityLocal {

    @PersistenceContext(unitName = "ENIT")
    private EntityManager em;

    @Override
    public void add(Speciality speciality) {
        em.persist(speciality);
    }

    @Override
    public void update(Speciality speciality) {
        em.merge(speciality);
    }

    @Override
    public void delete(int id) {
        Speciality speciality = em.find(Speciality.class, id);
        if (speciality != null) {
            em.remove(speciality);
        }
    }

    @Override
    public List<Speciality> findAll() {
        return em.createQuery("SELECT s FROM Speciality s", Speciality.class).getResultList();
    }
}
