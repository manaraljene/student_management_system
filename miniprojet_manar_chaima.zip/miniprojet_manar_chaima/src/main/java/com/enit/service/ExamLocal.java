package com.enit.service;

import java.util.List;
import jakarta.ejb.Local;

import com.enit.entities.Exam;

@Local
public interface ExamLocal {
    void add(Exam exam);

    void update(Exam exam);

    void delete(int id);

    List<Exam> findAll();
}
