package com.enit.controller;

import com.enit.entities.Student;
import com.enit.service.StudentLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/students")
public class StudentController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    @EJB
    private StudentLocal studentService;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("edit".equals(action)) {
            String studentId = request.getParameter("id");
            Student student = studentService.getStudentById(studentId);
            request.setAttribute("student", student);
        }
        
        List<Student> students = studentService.getAllStudents();
        request.setAttribute("students", students);
        request.getRequestDispatcher("/student.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("add".equals(action)) {
            String id = request.getParameter("id");
            String name = request.getParameter("name");
            Student student = new Student(id, name);
            studentService.addStudent(student);
        } 
        else if ("update".equals(action)) {
            String id = request.getParameter("id");
            String name = request.getParameter("name");
            Student student = new Student(id, name);
            studentService.updateStudent(student);
        } 
        else if ("delete".equals(action)) {
            String id = request.getParameter("id");
            studentService.deleteStudent(id);
        }
        
        response.sendRedirect("students");
    }
}