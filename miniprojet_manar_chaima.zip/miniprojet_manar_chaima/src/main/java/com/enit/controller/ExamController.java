package com.enit.controller;

import com.enit.entities.Exam;
import com.enit.service.ExamLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/exams")
public class ExamController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    private ExamLocal examService;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Exam> exams = examService.findAll();
        request.setAttribute("exams", exams);
        request.getRequestDispatcher("/exam.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            String title = request.getParameter("title");
            examService.add(new Exam(title));
        } else if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            examService.delete(id);
        }

        response.sendRedirect("exams"); // Redirect to the GET method to refresh the list
    }
}
