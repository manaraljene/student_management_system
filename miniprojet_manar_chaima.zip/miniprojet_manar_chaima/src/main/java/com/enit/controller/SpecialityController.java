package com.enit.controller;

import com.enit.entities.Speciality;
import com.enit.service.SpecialityLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/specialities")
public class SpecialityController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    private SpecialityLocal specialityService;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Speciality> specialities = specialityService.findAll();
        request.setAttribute("specialities", specialities);
        request.getRequestDispatcher("/speciality.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            String name = request.getParameter("name");
            specialityService.add(new Speciality(name));
        } else if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            specialityService.delete(id);
        }

        response.sendRedirect("specialities"); // Redirect to the GET method to refresh the list
    }
}
