package com.enit.controller;

import com.enit.entities.Session;
import com.enit.entities.SessionId;
import com.enit.service.SessionLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/sessions")
public class SessionController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    private SessionLocal sessionService;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Session> sessions = sessionService.findAll();
        request.setAttribute("sessions", sessions);
        request.getRequestDispatcher("/session.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            String idStudent = request.getParameter("idStudent");
            int idExam = Integer.parseInt(request.getParameter("idExam"));
            float mark = Float.parseFloat(request.getParameter("mark"));
            SessionId sessionId = new SessionId(idStudent, idExam);
            Session session = new Session();
            session.setSessionId(sessionId);
            session.setMark(mark);
            sessionService.add(session);
        } else if ("delete".equals(action)) {
            String idStudent = request.getParameter("idStudent");
            int idExam = Integer.parseInt(request.getParameter("idExam"));
            SessionId sessionId = new SessionId(idStudent, idExam);
            Session session = new Session();
            session.setSessionId(sessionId);
            sessionService.update(session);  // Assuming you want to soft delete or mark as inactive
        }

        response.sendRedirect("sessions"); // Redirect to the GET method to refresh the list
    }
}
