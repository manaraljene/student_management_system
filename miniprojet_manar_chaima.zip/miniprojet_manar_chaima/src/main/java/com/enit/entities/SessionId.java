package com.enit.entities;

import java.io.Serializable;
import jakarta.persistence.Embeddable;

@Embeddable
public class SessionId implements Serializable {
    private static final long serialVersionUID = 1L;

    private String idStudent;
    private int idExam;

    // Default constructor
    public SessionId() {}

    // Parameterized constructor
    public SessionId(String idStudent, int idExam) {
        this.idStudent = idStudent;
        this.idExam = idExam;
    }

    // Getters and Setters
    public String getIdStudent() {
        return idStudent;
    }

    public void setIdStudent(String idStudent) {
        this.idStudent = idStudent;
    }

    public int getIdExam() {
        return idExam;
    }

    public void setIdExam(int idExam) {
        this.idExam = idExam;
    }

    // Override equals() and hashCode()
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        SessionId that = (SessionId) obj;

        if (idExam != that.idExam) return false;
        return idStudent != null ? idStudent.equals(that.idStudent) : that.idStudent == null;
    }

    @Override
    public int hashCode() {
        int result = idStudent != null ? idStudent.hashCode() : 0;
        result = 31 * result + idExam;
        return result;
    }
}
