package com.enit.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Entity
@Table(name="student")
public class Student {
    @Id
    private String idStudent;
    private String nameStudent;
    
    // Default constructor
    public Student() {}
    
    // Constructor with ID and Name
    public Student(String idStudent, String nameStudent) {
        this.idStudent = idStudent;
        this.nameStudent = nameStudent;
    }
    
    // Getters and Setters
    public String getIdStudent() {
        return idStudent;
    }
    
    public void setIdStudent(String idStudent) {
        this.idStudent = idStudent;
    }
    
    public String getNameStudent() {
        return nameStudent;
    }
    
    public void setNameStudent(String nameStudent) {
        this.nameStudent = nameStudent;
    }
}